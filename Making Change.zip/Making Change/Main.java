import java.lang.Math;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter denominations : ");
        int n = sc.nextInt();
        int d[] = new int[n];

        for(int i=0;i<n;i++)
        {
            System.out.println("Enter for d["+(i+1)+"] : ");
            d[i]=sc.nextInt();
        }
        System.out.println("Enter how many rupees : ");
        int rupees = sc.nextInt();
        int amount = rupees;

        int c[][] = new int[3][9];

        for (int i = 0; i < n; i++) {
            c[i][0] = 0;
            for (int j = 2; j <= rupees; j++) {
                if (i == 0) {
                    c[i][j] = 1 + c[0][j - d[0]];
                } else if (j < d[i]) {
                    c[i][j] = c[i - 1][j];
                } else {
                    c[i][j] = (int) Math.min(c[i - 1][j], 1 + c[i][j - d[i]]);
                }
            }
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j <= rupees; j++) {
                System.out.print(c[i][j] + "\t");
            }
            System.out.println();
        }
    }
}
