import java.util.*;
class lcs
{
	Scanner sc=new Scanner(System.in);
	String first="";
	String second="";
	int len_f,len_s,k=0;
	char newa[]=new char[10];
	char to_f[]=new char[20];
	char to_s[]=new char[20];
	int m[][]=new int[20][100];


	void enter()
	{
		System.out.println("enter first string");
		first=sc.next();
		System.out.println("enter second string");
		second=sc.next();	
		len_f=first.length();
		len_s=second.length();
		to_f=first.toCharArray();
		to_s=second.toCharArray();	
	}

	void matrix()
	{
		for(int t=0;t<=len_f;t++)
			m[t][0]=0;
		for(int t=0;t<=len_s;t++)
			m[0][t]=0;
		for(int i=1;i<=len_f;i++)
		{
			for(int j=1;j<=len_s;j++)
			{
				if(to_f[i-1]==to_s[j-1])
				{
					m[i][j]=m[i-1][j-1]+1;
				}
				else
				{
					m[i][j]=max(m[i-1][j],m[i][j-1]);
				}
			}
		}
		//
	}

	int max(int a,int b)
	{
		if(a>=b)
			return a;
		else
			return b;
	}

	void display()
	{
		for(int i=0;i<=len_f;i++)
		{
			for(int j=0;j<=len_s;j++)
			{
				System.out.print(m[i][j]+"  ");
			}
			System.out.println();
		}
		backtrack(len_f,len_s);
	}

	void backtrack(int r,int c)
	{
		if(r!=0 || c!=0)
		{
				if(to_f[r-1]==to_s[c-1])
				{
					newa[k++]=to_f[r-1];
					//System.out.println(to_f[r-1]);
					backtrack(r-1,c-1);
				}
				else
				{
					if(m[r][c-1]>=m[r-1][c])
					{
						backtrack(r,c-1);
					}
					else
					{
						backtrack(r-1,c);
					}
				}
		}
		else
		{
				System.out.println("size of longest common subsequence -> "+m[len_f][len_s]);
				System.out.print("longest common subsequence -> ");
				for(int i=k-1;i>=0;i--)
				{
					System.out.print(newa[i]);
				}
		}
	}

}
class main
{
	public static void main(String z[])
	{
		lcs l=new lcs();
		l.enter();
		l.matrix();
		l.display();
	}
}